package bah.tahi.crossword.models;

/**
 * Enumérations des directions.
 */
public enum Direction {
	HORIZONTAL, VERTICAL;
}
